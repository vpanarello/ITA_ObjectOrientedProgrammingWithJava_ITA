import java.io.IOException;

public class BancoPalavrasExceptions extends IOException {

	public BancoPalavrasExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
