
public interface FormatadorNome {
	
	public abstract String formatarNome(String nome, String sobrenome);
	
	
}
